const Empresas = () => {
    return (
        <div>Minhas Empresas</div>
    )
}

export default Empresas