import Image from "next/image";
//https://www.youtube.com/watch?v=vCOSTG10Y4o&ab_channel=LamaDev
import Banner from "@/components/banner/Banner";
import Button from "@/components/button/Button";
import Link from "next/link";
import styles from "./page.module.css";

const Home = () => {
  // throw new Error("error in home");
  // return <div>Hello world!</div>
  return (
    <main className={styles.main}>
      <Banner type="overlay" banner="banner">
        <h1 className={styles.bannerTitle}>Minhas Empresas</h1>
        <p className={styles.bannerText}>
          Mantenha o controle da sua empresa
        </p>
        <Link href="/empresas">
          <Button text="Cadastre sua Empresa" />
        </Link>
      </Banner>
      <div className={styles.container}>
        <div className={styles.sectionB}>
          <div className={styles.sectionB1}>
            <h2 className={styles.title}>O que é esse serviço?</h2>
            <p className={styles.text}>
              Quando você insere um CNPJ no campo disponível, verificamos na Receita Federal se seu CPF
              está incluído dentre os representantes do quadro societário ou no registro de 
              "Representante" daquele CNPJ; Se estiver, a empresa é adicionada ao seu perfil.
            </p>

            {/* <Link href="/matriculas">
              <Button text="Ir até Matrículas" />
            </Link> */}
          </div>
          <div className={styles.sectionB2}>
            <div className={styles.cardContainer}>
              {/* <Card
                title="Boletim"
                subtitle="Confira o boletim e frequência escolares."
              >
                <BsCardList className={styles.icon} />
              </Card>
              <Card
                title="Calendário"
                subtitle="Veja o calendário escolar do ano letivo."
                bg="primary"
              >
                <BsCalendarDate className={styles.icon} />
              </Card>
            </div>
            <div className={styles.cardContainer}>
              <Card
                title="Cardápio"
                subtitle="Confira o cardápio da escola."
                bg="primaryLight"
              >
                <IoRestaurantOutline className={styles.icon} />
              </Card>
              <Card
                title="Declarações"
                subtitle="Emita a declaração de escolaridade."
                bg="pink"
              >
                <IoDocumentTextOutline className={styles.icon} />
              </Card> */}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

export default Home