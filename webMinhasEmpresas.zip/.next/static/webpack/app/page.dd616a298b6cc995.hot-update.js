/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/page",{

/***/ "(app-pages-browser)/./src/app/page.module.css":
/*!*********************************!*\
  !*** ./src/app/page.module.css ***!
  \*********************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("// extracted by mini-css-extract-plugin\nmodule.exports = {\"main\":\"page_main__GlU4n\",\"container\":\"page_container__aoG4z\",\"title\":\"page_title__3jonF\",\"text\":\"page_text__LcLL2\",\"bannerTitle\":\"page_bannerTitle__g34ok\",\"bannerText\":\"page_bannerText__ylMIS\",\"sectionB\":\"page_sectionB__zHuIn\",\"sectionB1\":\"page_sectionB1__7Z2Of\",\"sectionB2\":\"page_sectionB2__d0rqi\",\"cardContainer\":\"page_cardContainer__uo0Ub\",\"icon\":\"page_icon__AYuK3\",\"sectionC\":\"page_sectionC__fsx9K\",\"sectionC1\":\"page_sectionC1__xOOHf\",\"sectionC2\":\"page_sectionC2___jj08\",\"container2\":\"page_container2__Q7hB1\"};\n    if(true) {\n      // 1715986669030\n      var cssReload = __webpack_require__(/*! ./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js */ \"(app-pages-browser)/./node_modules/next/dist/compiled/mini-css-extract-plugin/hmr/hotModuleReplacement.js\")(module.id, {\"publicPath\":\"/_next/\",\"esModule\":false,\"locals\":true});\n      module.hot.dispose(cssReload);\n      \n    }\n  \nmodule.exports.__checksum = \"c712111a943b\"\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9hcHAvcGFnZS5tb2R1bGUuY3NzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0Esa0JBQWtCO0FBQ2xCLE9BQU8sSUFBVTtBQUNqQjtBQUNBLHNCQUFzQixtQkFBTyxDQUFDLHdNQUEwSSxjQUFjLHNEQUFzRDtBQUM1TyxNQUFNLFVBQVU7QUFDaEI7QUFDQTtBQUNBO0FBQ0EseUJBQXlCIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3NyYy9hcHAvcGFnZS5tb2R1bGUuY3NzPzI3ZjMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gZXh0cmFjdGVkIGJ5IG1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXG5tb2R1bGUuZXhwb3J0cyA9IHtcIm1haW5cIjpcInBhZ2VfbWFpbl9fR2xVNG5cIixcImNvbnRhaW5lclwiOlwicGFnZV9jb250YWluZXJfX2FvRzR6XCIsXCJ0aXRsZVwiOlwicGFnZV90aXRsZV9fM2pvbkZcIixcInRleHRcIjpcInBhZ2VfdGV4dF9fTGNMTDJcIixcImJhbm5lclRpdGxlXCI6XCJwYWdlX2Jhbm5lclRpdGxlX19nMzRva1wiLFwiYmFubmVyVGV4dFwiOlwicGFnZV9iYW5uZXJUZXh0X195bE1JU1wiLFwic2VjdGlvbkJcIjpcInBhZ2Vfc2VjdGlvbkJfX3pIdUluXCIsXCJzZWN0aW9uQjFcIjpcInBhZ2Vfc2VjdGlvbkIxX183WjJPZlwiLFwic2VjdGlvbkIyXCI6XCJwYWdlX3NlY3Rpb25CMl9fZDBycWlcIixcImNhcmRDb250YWluZXJcIjpcInBhZ2VfY2FyZENvbnRhaW5lcl9fdW8wVWJcIixcImljb25cIjpcInBhZ2VfaWNvbl9fQVl1SzNcIixcInNlY3Rpb25DXCI6XCJwYWdlX3NlY3Rpb25DX19mc3g5S1wiLFwic2VjdGlvbkMxXCI6XCJwYWdlX3NlY3Rpb25DMV9feE9PSGZcIixcInNlY3Rpb25DMlwiOlwicGFnZV9zZWN0aW9uQzJfX19qajA4XCIsXCJjb250YWluZXIyXCI6XCJwYWdlX2NvbnRhaW5lcjJfX1E3aEIxXCJ9O1xuICAgIGlmKG1vZHVsZS5ob3QpIHtcbiAgICAgIC8vIDE3MTU5ODY2NjkwMzBcbiAgICAgIHZhciBjc3NSZWxvYWQgPSByZXF1aXJlKFwiL2hvbWUvdXN1YXJpby9Eb2N1bWVudG9zL0lwbGFucmlvL21pbmhhc0VtcHJlc2FzL3dlYi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL21pbmktY3NzLWV4dHJhY3QtcGx1Z2luL2htci9ob3RNb2R1bGVSZXBsYWNlbWVudC5qc1wiKShtb2R1bGUuaWQsIHtcInB1YmxpY1BhdGhcIjpcIi9fbmV4dC9cIixcImVzTW9kdWxlXCI6ZmFsc2UsXCJsb2NhbHNcIjp0cnVlfSk7XG4gICAgICBtb2R1bGUuaG90LmRpc3Bvc2UoY3NzUmVsb2FkKTtcbiAgICAgIFxuICAgIH1cbiAgXG5tb2R1bGUuZXhwb3J0cy5fX2NoZWNrc3VtID0gXCJjNzEyMTExYTk0M2JcIlxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/app/page.module.css\n"));

/***/ })

});